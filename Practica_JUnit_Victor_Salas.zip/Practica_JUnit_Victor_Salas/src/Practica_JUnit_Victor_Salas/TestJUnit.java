package Practica_JUnit_Victor_Salas;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class TestJUnit {
	EmpleadoBR e1, e2, e3, e4, e5, e6, e7, e8;

	@Before
	public void antesQue() {
		e1 = new EmpleadoBR(0, 0, 0);
		e2 = new EmpleadoBR(0, 1500, 3);
		e3 = new EmpleadoBR(0, 1499.99f, 0);
		e4 = new EmpleadoBR(1, 1250, 8);
		e5 = new EmpleadoBR(1, 1000, 0);
		e6 = new EmpleadoBR(1, 999.99f, 3);
		e7 = new EmpleadoBR(1, 500, 0);
		e8 = new EmpleadoBR(1, 0, 8);

	}

	@Test
	public void comprobarBruto() {
		assertEquals(1360, e1.calcularSalarioBruto(0, 2000, 8), 0);
		assertEquals(1260, e1.calcularSalarioBruto(0, 1500, 3), 0);
		assertEquals(1100, e1.calcularSalarioBruto(0, 1499.99f, 0), 0);
		assertEquals(1760, e1.calcularSalarioBruto(1, 1250, 8), 0);
		assertEquals(1600, e1.calcularSalarioBruto(1, 1000, 0), 0);
		assertEquals(1560, e1.calcularSalarioBruto(1, 999.99f, 3), 0);
		assertEquals(1500, e1.calcularSalarioBruto(1, 500, 0), 0);
		assertEquals(1660, e1.calcularSalarioBruto(1, 0, 8), 0);

	}

	@Test
	public void comprobarNeto() {
		assertEquals(1640, e1.calcularSalarioNeto(2000), 0);
		assertEquals(1230, e2.calcularSalarioNeto(1500), 0);
		assertEquals(1259.9916, e3.calcularSalarioNeto(1499.99f), 5);
		assertEquals(1050, e4.calcularSalarioNeto(1250), 0);
		assertEquals(840, e5.calcularSalarioNeto(1000), 0);
		assertEquals(999.99, e6.calcularSalarioNeto(999.99f), 5);
		assertEquals(500, e7.calcularSalarioNeto(500), 0);
		assertEquals(0, e8.calcularSalarioNeto(0), 0);
	}

}