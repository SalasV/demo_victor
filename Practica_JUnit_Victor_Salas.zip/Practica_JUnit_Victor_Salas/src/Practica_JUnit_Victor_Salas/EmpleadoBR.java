package Practica_JUnit_Victor_Salas;

public class EmpleadoBR {
	private int tipo;
	private float ventasMes;
	private float horesExtra;
	private float salario;

	public EmpleadoBR(int tipo, float ventasMes, float horesExtra) {
		this.tipo = tipo;
		this.ventasMes = ventasMes;
		this.horesExtra = horesExtra;
	}

	public float calcularSalarioBruto(int tipo, float ventasMes, float horasExtra) {
		if (tipo == 0)
			this.salario = 1000;
		else
			this.salario = 1500;

		if (ventasMes >= 1000 && ventasMes < 1500)
			this.salario = this.salario + 100;
		else if (ventasMes >= 1500)
			this.salario = this.salario + 200;

		return this.salario + (horasExtra * 20);
	}

	public float calcularSalarioNeto(float salario) {
		if (salario >= 1000 && salario < 1500) {
			salario = (salario - (salario * 0.16f));
		} else if (salario >= 1500)
			salario = (salario - (salario * 0.18f));
		return salario;
	}
}
